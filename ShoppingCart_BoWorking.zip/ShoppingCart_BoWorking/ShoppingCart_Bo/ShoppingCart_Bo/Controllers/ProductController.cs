﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using ShoppingCart_Bo.Models;
using ShoppingCart_Bo.Data;
using Microsoft.AspNetCore.Mvc;

namespace ShoppingCart_Bo.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult DisplayProduct()
        {
            List<Product> productlists = ProductData.GetAllProducts();
            ViewData["productlists"] = productlists;
            ViewData["checkview"] = "defaultpage"; //to let homepage know if the value is checked
            return View();
        }

        public IActionResult Search(string search)
        {
            List<Product> searchedproductlists = ProductData.GetProductSearch(search);
            if (searchedproductlists == null)
            {
                ViewData["nulldata"] = "null";
                ViewData["checkview"] = "searchpage";
            }
            else
            {
                ViewData["foundproducts"] = searchedproductlists;
                ViewData["checkview"] = "searchpage";
            }
            return View();
        }

    }
}
