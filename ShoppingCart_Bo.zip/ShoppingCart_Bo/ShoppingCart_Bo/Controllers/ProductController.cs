﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using ShoppingCart_Bo.Models;
using ShoppingCart_Bo.Data;
using Microsoft.AspNetCore.Mvc;

namespace ShoppingCart_Bo.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult DisplayProduct()
        {
            List<Product> productlists = ProductData.GetAllProducts();
            ViewData["productlists"] = productlists;
            return View();
        }

    }
}
