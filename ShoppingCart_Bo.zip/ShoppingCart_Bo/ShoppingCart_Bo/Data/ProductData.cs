﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ShoppingCart_Bo.Models;
using ShoppingCart_Bo.Controllers;
using System.Data.SqlClient;

namespace ShoppingCart_Bo.Data
{
    public class ProductData
    {
        //Remember to change connectionstrong according to your server -Bo 
        protected static readonly string connectionString = "Server=LAPTOP-MAV6SM0F;" +
                                                               "Database=ShoppingCart;" +
                                                                "Integrated Security=true";
    public static List<Product> GetAllProducts()
        {
            List<Product> productslist = new List<Product>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string sql = @"SELECT product.Id,product.Image,product.Title,product.Description,product.Price from product";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Product product = new Product()
                    {
                        Id = (int)reader["Id"],
                        Image = (string)reader["Image"],
                        Title = (string)reader["Title"],
                        Description = (string)reader["Description"],
                        Price = (int)reader["Price"]
                    };
                    productslist.Add(product);
                }

            }
            return productslist;
        }
    
    
    }
}
