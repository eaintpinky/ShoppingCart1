﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart_Bo.Models
{
    public class Session
    {
        public int SessonId { get; set; }
        public string Username { get; set; }
    }
}
