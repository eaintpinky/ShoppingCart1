﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using ShoppingCart_Bo.Models;
using ShoppingCart_Bo.Data;
using Microsoft.AspNetCore.Mvc;

namespace ShoppingCart_Bo.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult DisplayProduct()
        {
            List<Product> productlists = ProductData.GetAllProducts();
            ViewData["productlists"] = productlists;
            ViewBag.a = 1; //to let homepage know if the value is checked
            //if logged in
            ViewData["customer"] = "John"; //this need to change after combining with YX
            return View();
        }
        [HttpPost]
        public IActionResult Search(string search)
        {
            List<Product> searchedproductlists = ProductData.GetProductSearch(search);
            if (searchedproductlists.Count == 0)
            {         //if logged in
                ViewData["customer"] = "John"; //this need to change after combining with YX
                ViewBag.a = 3;
            }
            else
            {      //if logged in
                ViewData["customer"] = "John"; //this need to change after combining with YX
                ViewData["foundproducts"] = searchedproductlists;
                ViewBag.a = 2;
            }
            return View("DisplayProduct");
        }


    }
}
